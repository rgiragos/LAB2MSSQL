const dotenv = require('dotenv');
dotenv.config({ path: './config.env' }); // this line has to come first since
//we need to tell where is the config file.
const app = require('./app');
const port = process.env.PORT || 3000;
app.listen(port, () => {
console.log(`App running on port ${port}...`);
});
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

const corsOptions = {
  origin: 'http://localhost:6000',
};

app.use(cors(corsOptions));

app.get('/test', (req, res) => {
  res.send('Hello from Express!');
});

app.listen(6000, () => {
  console.log('Express app listening on port 6000');
});
